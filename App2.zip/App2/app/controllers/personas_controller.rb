class PersonasController < ApplicationController
  def index
    @personas = Persona.all
  end

  def show
    @persona = Persona.find(params[:id])
  end

  def update
    @persona = Persona.find(params[:id])

    if @persona.update(person_param)
      redirect_to personas_path, notice: "Datos guardados correctamente!"
    else
      render :edit, status: :unprocessable_entity
    end
  end

  private
  
  def person_param
    params.require(:persona).permit(:nombre, :dni, :capitulo_id)
  end
end