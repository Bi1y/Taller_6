class Persona < ApplicationRecord
    belongs_to :capitulo
    
    def nombre_capitulo
      Capitulo.find(capitulo_id).name
    end
  end
  
